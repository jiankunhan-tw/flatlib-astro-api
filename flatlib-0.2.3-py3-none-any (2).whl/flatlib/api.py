
from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
from flatlib.chart import Chart
from flatlib.datetime import Datetime
from flatlib.geopos import GeoPos
import pytz
from datetime import datetime

app = FastAPI()

@app.get("/chart")
def generate_chart(
    date: str = Query(..., description="格式為 YYYY-MM-DD"),
    time: str = Query(..., description="格式為 HH:MM"),
    lat: float = Query(...),
    lon: float = Query(...),
    tz: str = Query(default="Asia/Taipei")
):
    try:
        # 組成當地時間字串
        naive_dt = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")
        local_tz = pytz.timezone(tz)
        local_dt = local_tz.localize(naive_dt)
        utc_dt = local_dt.astimezone(pytz.utc)

        # 構造 flatlib 所需物件
        dt_str = utc_dt.strftime("%Y/%m/%d")
        time_str = utc_dt.strftime("%H:%M")
        pos = GeoPos(lat, lon)
        dateTime = Datetime(dt_str, time_str)

        # 建立星盤
        chart = Chart(dateTime, pos)

        # 擷取行星與宮位資訊
        planets = {obj.id: {'sign': obj.sign, 'lon': obj.lon, 'lat': obj.lat} for obj in chart.objects}
        houses = {h.id: h.sign for h in chart.houses}

        return {"datetime_utc": utc_dt.isoformat(), "planets": planets, "houses": houses}

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
